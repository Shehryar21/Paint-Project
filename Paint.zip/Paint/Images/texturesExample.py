#UsingKeyboard.py
from random import *
from pygame import * 
size=(800,600)
screen = display.set_mode(size)
black=0,0,0
green=0,255,0
red=255,0,0
yellow=255,255,0
white=255,255,255
omx,omy=0,0
picnames=["brick.png","dirt.png","sky.png","grass.png"]#list of names

textures=[]
for name in picnames:
    pic=image.load(name)
    textures.append(pic)
###at this point, the textures list has all the images
    #going back to zero, modula

canvasRect=Rect(100,50,600,500)
screen.fill((255,170,200))
draw.rect(screen,white,canvasRect)
pos=0
samplePic=textures[0].subsurface((0,0,100,100))
screen.blit(samplePic,(25,50))
running = True
while running:
    for evt in event.get(): 
        if evt.type == QUIT: 
            running = False
        if evt.type==MOUSEBUTTONDOWN:
            n=len(textures)
            if evt.button==4:
                pos=(pos+1)%n
            if evt.button==5:
                pos=(pos-1+n)%n
            samplePic=textures[pos].subsurface((mx-25,my-25,50,50))
            screen.blit(samplePic,(mx-10,my-10))
            
    mx,my=mouse.get_pos()
    mb=mouse.get_pressed()
    if canvasRect.collidepoint(mx,my):
        if mb[0]==1:
            draw.line(screen,(111,111,111),(omx,omy),(mx,my),2)
        if mb[2]==1:
            samplePic=textures[pos].subsurface((mx-25,my-25,50,50))
            screen.blit(samplePic,(mx-10,my-10))
        
    omx,omy=mx,my
    display.flip() 
quit() 
